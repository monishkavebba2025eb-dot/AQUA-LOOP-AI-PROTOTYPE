# Aqua-Loop-AI

Aqua-Loop-AI is an early-stage water conservation concept for AI data centres. It demonstrates how a dashboard could help operators monitor cooling-water use, notice unusual consumption, and consider safe water-reuse opportunities.

## Prototype features
- Sample water-use and water-reuse figures.
- An illustrative weekly water-use chart.
- A button that displays a simulated high-water-use alert.
- A simple monitor, analyse, and recommend workflow.

## How to run the demo
1. Keep `index.html`, `style.css`, and `script.js` in the same folder.
2. Open `index.html` in a web browser.
3. Click **Simulate high-use alert** to see the demonstration alert.

## Important limitations
This is a front-end concept demonstration only. All figures and chart values are simulated. It does not connect to real data-centre equipment, sensors, a water-treatment system, or a trained AI model. The alert is scripted and is not a validated leak detector. Any real water-reuse plan would require water-quality testing and assessment by qualified engineering and water-treatment specialists.

## Files
- `index.html` — dashboard layout and content.
- `style.css` — dashboard styling and responsive layout.
- `script.js` — simulated high-use alert interaction.
