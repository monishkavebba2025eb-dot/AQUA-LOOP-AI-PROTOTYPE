// Aqua-Loop-AI: simulated dashboard alert interaction.
// Demonstration only: no real sensor data or trained AI model is used.

const simulateButton = document.getElementById("simulate");
const alertBox = document.getElementById("alert");

if (simulateButton && alertBox) {
  simulateButton.addEventListener("click", () => {
    alertBox.classList.add("warning");
    alertBox.innerHTML = `
      <span aria-hidden="true">⚠</span>
      <div>
        <strong>High water usage detected (simulated)</strong>
        <p>Suggested action: inspect flow-meter readings for possible leaks and review whether suitable treated water can safely be reused.</p>
      </div>
    `;
    simulateButton.textContent = "Alert simulated";
  });
}
